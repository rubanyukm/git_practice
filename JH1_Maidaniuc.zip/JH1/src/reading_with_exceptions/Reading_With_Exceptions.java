package reading_with_exceptions;

import java.io.File; 
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class Reading_With_Exceptions { 
  
void process(String inputFilename) { 

    int number_to_read = 0;
    File file = new File(inputFilename); 

    try {
        String outputFilename;
        PrintStream os;
    try (Scanner input = new Scanner(file)) { 
        outputFilename = input.nextLine();
        os = new PrintStream(new FileOutputStream(outputFilename)); 
                
    if (input.hasNextInt()) { 
       number_to_read = input.nextInt();
    } else {
       number_to_read = -1;
}
    copyNumbers(input, os, number_to_read);
}
    os.close(); 
    printToScreen(outputFilename); 

} catch (FileNotFoundException e) {
    System.out.println("Can't find the file " + e);
}
}
    void copyNumbers(Scanner scan, PrintStream ps, int numIntsToRead) { 
    while (scan.hasNext()) { 
    if (numIntsToRead < 0) {
                
    System.out.println("Reading all the data from the file.");
    while(scan.hasNextInt()){
    int readNum = scan.nextInt();
    	ps.print(readNum);
    	ps.print("\n");
        ps.flush();
    System.out.println("Completed Reading the Data!");
}                
}
    if (!scan.hasNextInt()) {
               
    System.out.println("No Data Present in the File to Read!");
    scan.nextLine();                
}
}
}
    public static void main(String[] args) {
     Reading_With_Exceptions rwe = new Reading_With_Exceptions();
     @SuppressWarnings("resource")
     Scanner sc = new Scanner(System.in);
     System.out.println("Enter the Number of Files : "); 
    int num = sc.nextInt();
     System.out.println("Enter the FileName : "); 
     String file[] = new String[num];
     sc.nextLine();
    for (int x = 0; x < num; x++) {
     String filename = sc.nextLine();
     file[x] = filename;
}
    for (String files : file) {
     System.out.println("\\n\\n=========== Processing " + files + " ==========\n");
     rwe.process(files); 
}
}  
    private void printToScreen(String filename) { 
        Scanner scan = null;

        try {
        FileInputStream fis = new FileInputStream(filename);
        scan = new Scanner(fis);
            
        System.out.println("Data Present in the Output File is : \n");
            
        while (scan.hasNextLine()) {                
        System.out.println(scan.nextLine());
}
}   catch (FileNotFoundException e) {
            System.out.println("printToScreen: can't open: " + filename);
}   finally {
        if (scan != null) {
            scan.close();
}
}
}
}